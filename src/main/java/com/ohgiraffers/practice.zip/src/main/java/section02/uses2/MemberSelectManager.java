package section02.uses2;

public class MemberSelectManager {

    public MemberDTO[] selectAllMembers() {

        return new MemberDTO[] {

                new MemberDTO(1, "user01", "pass01", "홍길동", 20, '남'),
                new MemberDTO(1, "user01", "pass01", "홍길동", 20, '여'),
                new MemberDTO(1, "user01", "pass01", "홍길동", 20, '남'),
                new MemberDTO(1, "user01", "pass01", "홍길동", 20, '여'),
                new MemberDTO(1, "user01", "pass01", "홍길동", 20, '남')

        };
    }
}
