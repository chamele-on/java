package com.ohgiraffers.section02.extend.run;

public class DrunkenBunny extends Bunny{

    @Override
    public void cry() {
        System.out.println("봐니봐니봐니 당근~~~");
    }
}
