package com.ohgiraffers.section02.extend.run;

public interface Animal {

    public static void main(String[] args) {

    }
}
