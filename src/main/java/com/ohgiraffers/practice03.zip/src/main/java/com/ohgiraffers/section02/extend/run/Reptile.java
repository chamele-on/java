package com.ohgiraffers.section02.extend.run;

public class Reptile implements Animal{
}
