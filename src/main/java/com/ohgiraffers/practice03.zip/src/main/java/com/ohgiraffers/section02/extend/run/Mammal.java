package com.ohgiraffers.section02.extend.run;

public class Mammal implements Animal {
}
