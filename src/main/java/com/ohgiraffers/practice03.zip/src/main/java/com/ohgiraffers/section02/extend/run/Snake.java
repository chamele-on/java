package com.ohgiraffers.section02.extend.run;

public class Snake extends Reptile{
}
