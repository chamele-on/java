package com.ohgiraffers.section02.extend.run;

public class Rabbit extends Mamal{

    public void cry() {
        System.out.println("토끼가 울음소리를 냅니다.. 끽끽!!");
    }
}
