package com.ohgiraffers.section02.extend.run;

public class Bunny extends Rabbit {
    @Override
    public void cry() {
        System.out.println("바니바니 당근 당근");
    }
}
