package org.example.chap01requestmappinglecturesource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap01RequestMappingLectureSourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Chap01RequestMappingLectureSourceApplication.class, args);
	}

}
