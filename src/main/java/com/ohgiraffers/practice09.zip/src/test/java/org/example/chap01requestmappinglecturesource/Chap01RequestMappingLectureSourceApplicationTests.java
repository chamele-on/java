package org.example.chap01requestmappinglecturesource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chap01RequestMappingLectureSourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
