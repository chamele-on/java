package com.ohgiraffers.section02.headers;

@WebServlet("/headers")
public class ResponseHeaderPrintServlet extends HttpServlet{

    @Override
    protected void doGet(HttpServlet)
}
