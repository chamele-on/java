package com.ohgiraffers.section01.response;

import java.io.IOException;
import java.io.PrintWriter;

public class ResponseTestServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String hi = "안녕 여러분";

        StringBuilder responseBuilder = new StringBuilder();

        responseBuilder.append("<doctype html>\n")
                .append("<html>\n")
                .append("<head></head>\n")
                .append("<body>\n")
                .append("<h1>" + hi + "</h1>")
                .append("</body>\n")
                .append("</html>");

        resp.setContentType("text/html; charset= UTF-8");

        PrintWriter out = resp.getWriter();
        out.write(responseBuilder.toString());

        out.flush();
        out.close();
    }
}
