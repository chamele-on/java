package com.ohgiraffers.section01;

import java.util.*;

public class Application01 {

    public static void main(String[] args) {

        ArrayList alist = new ArrayList();

        List list = new ArrayList<>();

        alist.add("apple");
        alist.add(123);
        alist.add(45.67);
        alist.add(new Date());

        System.out.println("alist = " + alist);

        System.out.println("alist 의 size : " + alist.size());

        for(int i = 0; i < alist.size(); i++ ) {
            System.out.println(i + " : " + alist.get(i));
        }

        /* 필기. 원하는 인덱스 위치에 값을 추가할 수 있다.
        *  새로운 값이 들어가는 인덱스 위치에 값을 넣고 이후 인덱스는 하나씩 뒤로 밀리게 된다.
        * */

        alist.add(1, "banana");
        System.out.println("alist = " + alist);

        alist.remove(2);
        System.out.println("alist = " + alist);

        alist.set(1, true);
        System.out.println("alist = " + alist);

        List<String> stringList = new ArrayList<>();
//        stringList.add(123);
        stringList.add("apple");
        stringList.add("orange");
        stringList.add("mango");
        stringList.add("grape");

        System.out.println("stringList = " + stringList);
        Collections.sort(stringList);
        System.out.println("stringList = " + stringList);
        stringList = new LinkedList<>(stringList);

        Iterator<String> dIter = ((LinkedList<String>)stringList)

        List<String> descList = new ArrayList<>();

        while (dIter.hasNext()) {
            descList.add(dIter.next());
        }

        System.out.println("descList = " + descList);
    }
}
