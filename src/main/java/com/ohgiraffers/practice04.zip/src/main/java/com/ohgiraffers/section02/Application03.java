package com.ohgiraffers.section02;

import java.util.TreeSet;

public class Application03 {

    public static void main(String[] args) {

        TreeSet<String> tset = new TreeSet<>();

        test.add("java");
        test.add("mysql");
        test.add("jdbc");
        test.add("html");
        test.add("css");

        System.out.println("tset = " + tset);

        Set<Integer> lotto = new TreeSet<>();

        while (lotto.size() < 7) {

            lotto.add((int)) (Math.random() * 45) + 1);
        }

        System.out.println("lotto = " + lotto);

    }
}
