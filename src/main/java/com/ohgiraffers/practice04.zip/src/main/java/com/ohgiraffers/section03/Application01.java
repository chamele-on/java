package com.ohgiraffers.section03;

import java.util.*;

public class Application01 {

    public static void main(String[] args) {

        HashMap hmap = new HashMap();

        hmap.put("one", new Date());
        hmap.put(12, "red apple");
        hmap.put(33, 123);

        System.out.println("hmap = " + hmap);

        hmap.put(12, "fineapple");
        System.out.println("hmap = " + hmap);
        hmap.put(11, "fineapple");
        System.out.println("hmap = " + hmap);
        hmap.remove(11);
        System.out.println("hmap = " + hmap);
        System.out.println("키 12번에 대한 객체 : " + hmap.get(12));
        HashMap<String, String> hmap2 = new HashMap<>();

        hmap2.put("one", "java");
        hmap2.put("two", "mysql");
        hmap2.put("three", "jdbc");
        hmap2.put("four", "html");
        hmap2.put("five", "css");

        System.out.println("hmap2 = " + hmap2);

        Iterator<String> keyIter = hmap2.keySet().iterator();

        while (keyIter.hasNext()) {
            String key = (String) keyIter.next();
            String value = (String) hmap2.get(key);
            System.out.println(key + " = " + value);
        }

        Collection<String> values = hmap2.values();

        Iterator<String> valueIter = values.iterator();
        while (valueIter.hasNext()) {
            System.out.println(valueIter.next());
        }
        Object[] valueArr = values.toArray();
        for (int i = 0; i < valueArr.length; i++ ) {
            System.out.println(i + " : " + valueArr[i]);
        }
        Set<Map.Entry<String, String>> set = hmap2.entrySet();
        Iterator<Map.Entry<String, String>> entry = entryIter.next();
        while (entryIter.hasNext()) {
            Map.Entry<String, String> entry = entryIter.next();
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
    }
    }












