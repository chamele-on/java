package com.ohgiraffers.section02;

import java.util.LinkedHashSet;

public class Application02 {

    public static void main(String[] args) {

        LinkedHashSet<String> lhset = new LinkedHashSet<>();

        lhset.add("java");
        lhset.add("mysql");
        lhset.add("jdbc");
        lhset.add("html");
        lhset.add("css");

        System.out.println("lhset = " + lhset);
    }
}
