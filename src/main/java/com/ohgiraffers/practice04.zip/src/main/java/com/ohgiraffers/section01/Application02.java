package com.ohgiraffers.section01;

import java.util.List;

public class Application02 {

    public static void main(String[] args) {

        List<String> linkedList = new LinkedList<>();

        linkedList.add("apple");
        linkedList.add("banana");
        linkedList.add("orange");
        linkedList.add("mango");
        linkedList.add("grape");

        System.out.println(linkedList.size());

        for (int i = 0; i < linkedList.size(); i++) {
            System.out.println(i + " : " + linkedList.get(i));
        }

        linkedList.remove(1);

        linkedList.set(0, "fineapple");

        System.out.println("linkedList = " + linkedList);

        System.out.println(linkedList.isEmpty());

        linkedList.clear();

        System.out.println(linkedList.isEmpty());
    }
}
