package com.ohgiraffers.section01;

import java.util.LinkedList;
import java.util.Queue;

public class Application04 {

    public static void main(String[] args) {

        Queue<String> que = new LinkedList<>();

        que.offer("first");
        que.offer("second");
        que.offer("third");
        que.offer("fourth");
        que.offer("fifth");

        System.out.println("que = " + que);

        System.out.println("peek() : " + que.peek());
        System.out.println("peek() : " + que.peek());

        System.out.println("que = " + que);

        System.out.println("poll() : " + que.poll());
        System.out.println("poll() : " + que.poll());

        System.out.println("que = " + que);

    }
}
