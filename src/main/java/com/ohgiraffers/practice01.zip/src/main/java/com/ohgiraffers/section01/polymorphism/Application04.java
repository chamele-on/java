package com.ohgiraffers.section01.polymorphism;

public class Application04 {
}
