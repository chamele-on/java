package com.ohgiraffers.section02.abstractclass;

public class Application {
    public static void main(String[] args) {
        /* 수업목표. 추상클래스와 추상메소드에 대해 이해할 수 있다. */
        SmartPhone smartPhone = new SmartPhone();

        System.out.println(smartPhone instanceof SmartPhone);
        System.out.println(smartPhone instanceof Product);

        Product product = new SmartPhone();

        product.abstMethod();
        product.nonStaticMethod();
        product.staticMethod();

    }
}
