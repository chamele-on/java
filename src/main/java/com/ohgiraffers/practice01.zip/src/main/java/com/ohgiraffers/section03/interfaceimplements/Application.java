package com.ohgiraffers.section03.interfaceimplements;

public class Application {

    public static void main(String[] args) {

        InterProduct inter = new Product();

        inter.nonStaticMethod();
        inter.absMethod();

        InterProduct.staticMethod();

        System.out.println(InterProduct.MAX_NUM);



    }

}
