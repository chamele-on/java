package com.ohgiraffers.section01.polymorphism;

public class Application01 {
    public static void main(String[] args) {
        System.out.println("======동물 생성======");
        동물 animal = new 동물();
        animal.먹기();
        animal.달리기();
        animal.울기();

        /* 목차. 2. 동물 인스턴스 생성 후 메소드 호출 확인 */

        System.out.println("=======토끼생성========");
        토끼 rabbit = new 토끼();
        rabbit.먹기();
        rabbit.달리기();
        rabbit.울기();
        rabbit.점프();


        System.out.println("===========호랑이 생성=================");
        호랑이 tiger = new 호랑이();
        tiger.먹기();
        tiger.달리기();
        tiger.울기();
        tiger.물어뜯기();


        동물 a1 = new 토끼();
        동물 a2 = new 호랑이();

        System.out.println("=========동적 바인딩 확인===============");
        a1.울기();
        a2.울기();

        System.out.println("==========클래스 형변환 확인==================");
        ((토끼)a1).점프();
        ((호랑이)a2).물어뜯기();

        System.out.println("============instanceof 확인===================");
        System.out.println("a1이 호랑이 타입인 지 확인 : " + (a1 instanceof 호랑이));
        System.out.println("a1이 토끼 타입인 지 확인 : " + (a1 instanceof 토끼));
        System.out.println("a1이 동물 타입인 지 확인 : " + (a1 instanceof 동물));
        System.out.println("a1이 동물 타입인 지 확인 : " + (a1 instanceof 동물));
        System.out.println("a1이 Object 타입인 지 확인 : " + (a1 instanceof Object));

        System.out.println("====================");
        if (a1 instanceof 토끼) {
            ((토끼)a1).점프();
        }

        if (a1 instanceof 호랑이) {
            ((호랑이)a1).물어뜯기();
        }

        동물 a3 = (동물) new 토끼();
        동물 a4 = new 토끼();

        토끼 r4 = (토끼) a3;


    }
}
