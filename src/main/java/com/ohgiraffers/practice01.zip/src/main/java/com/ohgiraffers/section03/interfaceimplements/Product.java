package com.ohgiraffers.section03.interfaceimplements;

public class Product extends Object implements InterProduct {
    @Override
    public void nonStaticMethod() {
        System.out.println("InterProduct의 nonStaticMethod 오버라이딩한 메소드 호출됨...");
    }

    @Override
    public void absMethod() {

        System.out.println("InterProduct의 absMethod 오버라이딩한 메소드 호출됨...");

    }
}
