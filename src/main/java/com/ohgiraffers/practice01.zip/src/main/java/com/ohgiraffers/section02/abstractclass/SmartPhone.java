package com.ohgiraffers.section02.abstractclass;

public class SmartPhone extends Product {

    public SmartPhone() {}

    public void abstMethod() {
        System.out.println("Product 클래스의 추상메소드를 오버라이딩 한 메소드 호출...");
    }

    public void printSmartPhone() {
        System.out.println("SmartPhone 클래스의 일반 메소드 호출됨..");
    }
}
