package com.ohgiraffers.section01.polymorphism;

public class Application02 {

    public static void main(String[] args) {

        동물[] animals = new 동물[5];
        animals[0] = new 토끼();
        animals[1] = new 호랑이();
        animals[2] = new 토끼();
        animals[3] = new 호랑이();
        animals[4] = new 토끼();

        for (int i = 0; i < animals.length; i++) {
            animals[i].울기();
        }

        for (int i = 0; i < animals.length; i++) {
            animals[i].울기();

        }

        for (int i = 0; i < animals.length; i++) {
            if(animals[i] instanceof 토끼) {
                ((토끼) animals[i]).점프();
            } else if (animals[i] instanceof 호랑이) {
                ((호랑이) animals[i]).물어뜯기();
            } else {
                System.out.println("토끼나 호랑이가 아닙니다.");

            }
        }

    }
}
