package com.ohgiraffers.section01.polymorphism;

public class 동물 {

    public void 먹기() {
        System.out.println("동물이 먹이를 먹습니다.");
    }
    public void 달리기() {
        System.out.println("동물이 초원을 달립니다.");
    }
    public void 울기() {
        System.out.println("동물이 울음소리를 냅니다.");
    }
}
