package com.ohgiraffers.section01.polymorphism;

public class Application03 {

    public static void main(String[] args) {

        Application03 app3 = new Application03();

        동물 a1 = new 토끼();
        동물 a2 = new 호랑이();

        app3.먹이주기(a1);
        app3.먹이주기(a2);

        토끼 r1 = new 토끼();
        호랑이 t1 = new 호랑이();

        app3.먹이주기((동물)r1);
        app3.먹이주기((동물)t1);

        app3.먹이주기(new 토끼());
        app3.먹이주기(new 호랑이());
    }

    public void 먹이주기(동물 animal) {

        animal.먹기();
    }

}
