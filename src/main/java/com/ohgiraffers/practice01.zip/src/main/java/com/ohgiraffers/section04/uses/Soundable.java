package com.ohgiraffers.section04.uses;

public interface Soundable {
    void horn();
}
