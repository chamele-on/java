package com.ohgiraffers.section04.uses;

public class Car {

    public abstract void go();

    public abstract void stop();
}
