package com.ohgiraffers.section03.interfaceimplements;

public interface InterProduct {
}
