package com.ohgiraffers.section01.servicemethod;

@WebServlet ("/request-service")
public class ServiceMethodTestServlet extends HttpServlet {

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {

        HttpServletRequest httpRequest = (HttpServletRequest) req;
        HttpServletResponse httpResponse = (HttpServletResponse) res;

        String httpMethod = httpRequest.getMethod();

        System.out.println("httpMethod = " + httpMethod);

        if(("GET")).equals(httpMethod)) {
            doGet(httpRequest, httpResponse);
        } else if (("POST")).equls(httpMethod)) {
        doPost(httpRequest, httpResponse);
        }

        /* 필기.
        *   GET, POST
        *   -HEAD, OPTIONS, PUT, DELETE, TRACE, CONNECT
        *   - 하지만 대부분 GET, POST 주로 사용한다.
        * */

    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("GET 요청 처리할 메소드 호출함!!");
    }

}
